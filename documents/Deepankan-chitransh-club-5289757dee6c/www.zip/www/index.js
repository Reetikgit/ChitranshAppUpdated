const functions = require('firebase-functions');

const admin = require("firebase-admin")

const nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');

admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  databaseURL: 'https://chitransh-club.firebaseio.com/'
});


//google account credentials used to send email

var transporter = nodemailer.createTransport({

    host: 'smtp.gmail.com',
    port: 465,
    secure:true,
    auth: {

        user: 'reetikchitragupt@gmail.com',
        pass: 'mygmail797355670645'
    },
     tls: {
    // do not fail on invalid certs
    rejectUnauthorized: false
  }
});
// exports.solosinging = functions.database.ref('/SoloSinging/{pushID}')

//     .onWrite(async (change) => {
//          const snapshot = change.after;
//   const val = snapshot.val();

//   const mailOptions = {
//     from: '"Reetik " <reetikchitragupt@gmail.com>',
//     to: val.email,
//   };

//   // Building Email message.
//   mailOptions.subject = 'Sanchalana 2k20 ';
//  //for example
//   mailOptions.text ='Welcome '+val.name+' '+'Your registration for the event'+' '+val.event+' '+ 'with USN'+' '+val.usn+' '+ 'has been confirmed'+ ' Your unique Id is'+' '+ val.random;

//   try {
//     console.log(val.email);
//     await transporter.sendMail(mailOptions);
//     console.log('email sent to:', val.email);
//     transporter.close();
//     console.log(val.email)
//   } catch(error) {
//     console.error('There was an error while sending the email:'+val.email, error);
//   }
//   return null;
// });
//     exports.solodance = functions.database.ref('/SoloDance/{pushID}')

//     .onWrite(async (change) => {
//          const snapshot = change.after;
//   const val = snapshot.val();

//   const mailOptions = {
//     from: '"Reetik " <reetikchitragupt@gmail.com>',
//     to: val.email,
//   };

//   // Building Email message.
//   mailOptions.subject = 'Sanchalana 2k20 ';
//  //for example
//   mailOptions.text = 'Welcome '+val.name+' '+'Your registration for the event'+' '+val.event+' '+ 'with USN'+' '+val.usn+' '+ 'has been confirmed'+ ' Your unique Id is'+' '+ val.random;

//   try {
//     console.log(val.email);
//     await transporter.sendMail(mailOptions);
//     console.log('email sent to:', val.email);
//     transporter.close();
//     console.log(val.email)
//   } catch(error) {
//     console.error('There was an error while sending the email:'+val.email, error);
//   }
//   return null;
// });


// exports.instrumental = functions.database.ref('/SoloSinging/{pushID}')

//     .onWrite(async (change) => {
//          const snapshot = change.after;
//   const val = snapshot.val();

//   const mailOptions = {
//     from: '"Reetik " <reetikchitragupt@gmail.com>',
//     to: val.email,
//   };

//   // Building Email message.
//   mailOptions.subject = 'Sanchalana 2k20 ';
//  //for example
//   mailOptions.text = 'Welcome '+val.name+' '+'Your registration for the event'+' '+val.event+' '+ 'with USN'+' '+val.usn+' '+ 'has been confirmed'+ ' Your unique Id is'+' '+ val.random;

//   try {
//     console.log(val.email);
//     await transporter.sendMail(mailOptions);
//     console.log('email sent to:', val.email);
//     transporter.close();
//     console.log(val.email)
//   } catch(error) {
//     console.error('There was an error while sending the email:'+val.email, error);
//   }
//   return null;
// });
//     exports.solodance = functions.database.ref('/SoloDance/{pushID}')

//     .onWrite(async (change) => {
//          const snapshot = change.after;
//   const val = snapshot.val();


//   const mailOptions = {
//     from: '"Reetik " <reetikchitragupt@gmail.com>',
//     to: val.email,
//   };

//   // Building Email message.
//   mailOptions.subject = 'Sanchalana 2k20 ';
//  //for example
//   mailOptions.text = 'Welcome '+val.name+' '+'Your registration for the event'+' '+val.event+' '+ 'with USN'+' '+val.usn+' '+ 'has been confirmed'+ ' Your unique Id is'+' '+ val.random;

//   try {
//     console.log(val.email);
//     await transporter.sendMail(mailOptions);
//     console.log('email sent to:', val.email);
//     transporter.close();
//     console.log(val.email)
//   } catch(error) {
//     console.error('There was an error while sending the email:'+val.email, error);
//   }
//   return null;
// });
exports.sendEmail = functions.database.ref('/common/{pushID}')

    .onCreate((snapshot,context)=> {
   // const snapshot = change.after;
  const val = snapshot.val();


  const mailOptions = {
    from: '"Reetik " <reetikchitragupt@gmail.com>',
    to: val.email,
  };

  // Building Email message.
  mailOptions.subject = 'Sanchalana 2k20 ';
 //for example
  mailOptions.text = 'Welcome '+val.name+' '+'Your registration for the event'+' '+val.event+' '+ 'with USN'+' '+val.usn+' '+ 'has been confirmed'+ ' Your unique Id is'+' '+ val.random;

  try {
    console.log(val.email);
     transporter.sendMail(mailOptions);
    console.log('email sent to:', val.email);
    transporter.close();
    console.log(val.email)
  } catch(error) {
    console.error('There was an error while sending the email:'+val.email, error);
  }
  return null;
});
 exports.reciept = functions.database.ref('/common/{pushID}')

    .onUpdate(async (change) => {
         const snapshot = change.after;
  const val = snapshot.val();

  const mailOptions = {
    from: '"Reetik " <reetikchitragupt@gmail.com>',
    to: val.email,
  };

  // Building Email message.
  mailOptions.subject = 'Sanchalana 2k20 ';
 //for example
   //mailOptions.text = 'Hello '+val.name+' '+'We have successfully'+' '+' '+val.Payment+' '+'payment for the event'+val.event+' .'+ ' '+'Your this mail is your reciept for this event.'+' '+ 'Thankyou'+ '  ';
  mailOptions.html='<p style="color:orange;" >'+"Hello"+" "+val.name+'<br>'+"Your payment status has been updated and "+"we have recieved the payment of"+" "+val.Payment+" . "+"Your receipt is listed below"+'</p><br><h1 style="font-size:1.2em; color:black;border: 4px solid #ff8080;background:#F5EC92 ;border-radius: 20px;margin-left:2%; ">'+" "+'<p style="color:#ff3333;margin-left:23%;font-size:0.7rem">Sai Vidya Institue Of Technology</p>'+" "+'<br><hr>'+" "+'&nbsp; Receipt No: '+" "+val.random+'<br><br>'+" "+"&nbsp; Name :"+" "+val.name+'<br><br>'+"&nbsp; USN:"+" "+val.usn+'<br><br>'+"&nbsp; Event:"+" "+val.event+'<br><br>'+"&nbsp; Paid:"+" "+val.Payment+'<br><br>'+"&nbsp; Sem:"+" "+val.sem+'<br><br>'+"&nbsp; Branch:"+" "+val.branch+'</h1><br>'+" "+'<p style="color:black;font-size1.2em" >'+"We recommend you to take screenshot of the receipt for future authentications"+" "+'<br>'+"Thnakyou : "+"Team Sanchalana."+" ."+" "+'</p>'
  try {
    console.log(val.email);
    await transporter.sendMail(mailOptions);
    console.log('email sent to:', val.email);
    transporter.close();
    console.log(val.email)
  } catch(error) {
    console.error('There was an error while sending the email:'+val.email, error);
  }
  return null;
});

